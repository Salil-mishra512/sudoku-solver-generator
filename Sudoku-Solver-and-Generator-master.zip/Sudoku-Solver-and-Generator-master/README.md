Sudoku Generator:- A python program that generates a random uncompleted sudoku.





Sudoku Solver:- A python program that solves a unfinished sudoku.(If sudoku is not perfect it return the original sudoku):)
